# projekt2_webunivers

Projekt 2 - Web Univers - By Bjarke Holm

Nye teknikker jeg har lært i denne process:
1)z-index: til at bestemme hvad der skal ligge forrest i en stack 2) Opmærksomhed på at containere ikke overlapper hinanden, så hover (e.l.) funktioner forsvinder 3)
